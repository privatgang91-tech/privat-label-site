var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var products_exports = {};
__export(products_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(products_exports);
var import_axios = __toESM(require("axios"));
async function handler() {
  console.log("\u{1F6CD}\uFE0F [Privat Label Shop] R\xE9cup\xE9ration d\xE9taill\xE9e des produits...");
  try {
    const baseResponse = await import_axios.default.get("https://api.printful.com/store/products", {
      headers: { Authorization: `Bearer ${process.env.PRINTFUL_API_KEY}` }
    });
    const products = baseResponse.data.result || [];
    console.log(`\u{1F48E} Produits trouv\xE9s : ${products.length}`);
    const detailed = await Promise.all(
      products.map(async (p) => {
        try {
          const res = await import_axios.default.get(`https://api.printful.com/store/products/${p.id}`, {
            headers: { Authorization: `Bearer ${process.env.PRINTFUL_API_KEY}` }
          });
          const variants = res.data?.result?.sync_variants || [];
          const price = variants[0]?.retail_price || "\u2014";
          return {
            id: p.id,
            name: p.name,
            thumbnail_url: p.thumbnail_url,
            price
          };
        } catch (e) {
          console.warn(`\u26A0\uFE0F Impossible de r\xE9cup\xE9rer ${p.id}:`, e.message);
          return { id: p.id, name: p.name, thumbnail_url: p.thumbnail_url, price: "\u2014" };
        }
      })
    );
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ result: detailed })
    };
  } catch (error) {
    console.error("\u274C Erreur Printful :", error.response?.status, error.response?.data);
    return {
      statusCode: error.response?.status || 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        error: "Erreur lors du chargement des produits Printful",
        details: error.response?.data || error.message
      })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
